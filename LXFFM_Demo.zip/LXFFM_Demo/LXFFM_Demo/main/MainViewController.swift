//
//  MainViewController.swift
//  LXFFM_Demo
//
//  Created by Rainy on 2016/12/1.
//  Copyright © 2016年 Rainy. All rights reserved.
//

import UIKit

class MainViewController: UITabBarController {

    fileprivate let titles:[String] = ["发现","订阅听","播放","下载听","我的"]
    fileprivate let selectedImgNames:[String] = ["tabbar_find_h","tabbar_sound_h","tabbar_np_playnon","tabbar_download_h","tabbar_me_h"]
    fileprivate let normalImgNames:[String] = ["tabbar_find_n","tabbar_sound_n","tabbar_np_playnon","tabbar_download_n","tabbar_me_n"]
    fileprivate let VCs:[UIViewController] = [FindVC(),SubscribeVC(),PlayVC(),DownVC(),MineVC()]
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        
        
        setUpUI()

        // Do any additional setup after loading the view.
        
        
    }
}
extension MainViewController{
    
    
    fileprivate func setUpUI(){
        
        for item in 0..<titles.count {
            
            let vc = VCs[item]
            vc.tabBarItem.image = UIImage.init(named: normalImgNames[item])?.withRenderingMode(.alwaysOriginal)
            vc.tabBarItem.selectedImage = UIImage.init(named: selectedImgNames[item])?.withRenderingMode(.alwaysOriginal)
            let navc = UINavigationController.init(rootViewController: vc)
            vc.navigationItem.title = titles[item]
            self.addChildViewController(navc)
            
            
            
        }
        
    }
    
}
