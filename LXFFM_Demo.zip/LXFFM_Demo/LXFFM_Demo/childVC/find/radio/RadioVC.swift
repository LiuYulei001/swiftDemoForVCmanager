//
//  RadioVC.swift
//  LXFFM_Demo
//
//  Created by Rainy on 2016/12/1.
//  Copyright © 2016年 Rainy. All rights reserved.
//

import UIKit

class RadioVC: BasicVC {

    
    override func viewDidLoad() {
        
        view.backgroundColor = UIColor.green
    }
    
}
