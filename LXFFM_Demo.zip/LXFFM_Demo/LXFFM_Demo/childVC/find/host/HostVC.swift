//
//  HostVC.swift
//  LXFFM_Demo
//
//  Created by Rainy on 2016/12/1.
//  Copyright © 2016年 Rainy. All rights reserved.
//

import UIKit

class HostVC: BasicVC {

    override func viewDidLoad() {
        
        view.backgroundColor = UIColor.blue
    }
}
