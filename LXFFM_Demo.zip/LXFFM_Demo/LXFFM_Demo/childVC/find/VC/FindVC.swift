//
//  FindVC.swift
//  LXFFM_Demo
//
//  Created by Rainy on 2016/12/1.
//  Copyright © 2016年 Rainy. All rights reserved.
//
import UIKit
import SnapKit

class FindVC: BasicVC {

    lazy var subviewTitles:[String] = {
       
        let array = ["推荐", "分类","广播","榜单","主播","广播","榜单","主播"]
        return array
        
    }()
    
    lazy var VCManager:VCManagerView = {
       
        let manager = VCManagerView(frame:CGRect.init(x: 0, y: 0, width: kScreenW, height: 44))
        manager.delegate = self
        self.view.addSubview(manager)
        
        return manager
        
    }()
    lazy var pageMagager:PageManagerVC = {
       
        let manager = PageManagerVC.init(superController: self, childControllerS: [RecommendedVC(),CategoryVC(),HostVC(),RadioVC(),RankingListVC()])
        manager.delegate = self
        self.view.addSubview(manager.view)
        return manager
        
    }()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        view.backgroundColor = UIColor.white
        // Do any additional setup after loading the view.
        
        VCManager.title_font = UIFont.systemFont(ofSize: 15)
        VCManager.sliderWidthType = .ButtonWidth
        VCManager.title_array = subviewTitles
        setConstraint()
        
    }
    fileprivate func setConstraint(){
        
        pageMagager.view.snp.makeConstraints { (make) in
            make.top.equalTo(VCManager.snp.bottom)
            make.left.right.equalTo(view)
            make.bottom.equalTo(view.snp.bottom).offset(-49)
        }
    }

}

extension FindVC:VCManagerDelegate,PageManagerVC_Delegate{
    
    
    func VCManagerDidSelected(_ VCManager: VCManagerView, index: NSInteger, title: String) {
        
        pageMagager.setCurrentVCWithIndex(index)
    }
    func PageManagerDidFinishSelectedVC(indexOfVC: NSInteger) {
        VCManager.reloadSelectedBT(at: indexOfVC)
    }
    
}













