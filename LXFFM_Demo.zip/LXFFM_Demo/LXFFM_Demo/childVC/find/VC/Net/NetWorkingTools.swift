//
//  NetWorkingTools.swift
//  LXFFM_Demo
//
//  Created by Rainy on 2016/12/5.
//  Copyright © 2016年 Rainy. All rights reserved.
//

import Foundation
import Alamofire

enum RequestType {
    case GET
    case POST
}

class NetWorkingTools:NSObject{
    static let shareTools:NetWorkingTools = {
        let tools = NetWorkingTools()
        return tools
    }()
}
extension NetWorkingTools{
    
    func requestData(methodType:RequestType,urlString:String,parameters:[String:AnyObject]?,finished:@escaping(_ responseData:AnyObject?,_ error:NSError?)->()) {
        
        let requestCallBack = {(response:DataResponse<Any>) in
        
            if response.result.isSuccess {
                finished(response.result.value as AnyObject,nil)
            }else{
                finished(nil,response.result.error as NSError?)
            }
        }
        let HttpMethod:HTTPMethod = methodType == .GET ? .get : .post
        request(urlString, method: HttpMethod, parameters: parameters, encoding: URLEncoding.default, headers: nil).responseJSON(completionHandler: requestCallBack)
        
    }
    
}

// 用法：
//    NetWorkingTools.shareTools.requestData(methodType: .GET, urlString: "https://", parameters: nil){responseData,error in
//
//
//
//    }











